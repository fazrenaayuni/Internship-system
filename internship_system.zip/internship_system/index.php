<?php
session_start();
require_once __DIR__ . "/config/db.php";
require_once __DIR__ . "/config/navbar.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Internship Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background:#f4f6f9;">

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-8">

      <div class="card shadow">
        <div class="card-body p-5 text-center">
          <h1 class="fw-bold mb-2">Internship Management System</h1>
          <p class="text-muted mb-4">Please login or register to continue</p>

          <?php if(isset($_SESSION['user_id'])): ?>
            <a href="/dashboard/index.php" class="btn btn-primary px-4">Go to Dashboard</a>
          <?php else: ?>
            <a href="/auth/login.php" class="btn btn-primary px-4 me-2">Login</a>
            <a href="/auth/register.php" class="btn btn-outline-secondary px-4">Register</a>
          <?php endif; ?>

        </div>
      </div>

      <p class="text-center text-muted mt-3 small">
        © <?= date('Y') ?> Internship System
      </p>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>





