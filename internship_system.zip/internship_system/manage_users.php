<?php
session_start();
include "../config/db.php";
include "../config/navbar.php";
include "../config/sidebar.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin'){
    header("Location: ../auth/login.php");
    exit();
}
?>

<div class="col-md-9">
    <h3>Manage Users</h3>
    <p>Ini adalah page untuk admin manage users. Kau boleh paste table manage users dari `admin.php` sini.</p>
</div>
