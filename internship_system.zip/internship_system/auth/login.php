<?php
session_start();
include("../config/db.php");

$error = "";

if(isset($_POST['login'])){
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];

    // security: prepared statement
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if($user && password_verify($pass, $user['userPass'])){
        $_SESSION['user_id']   = $user['user_id'];
        $_SESSION['user_name'] = $user['user_name'];
        $_SESSION['role']      = $user['user_role'];

        header("Location: ../dashboard/index.php");
        exit();
    } else {
        $error = "Invalid email or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/auth.css">
</head>

<body class="auth-bg d-flex align-items-center justify-content-center">

<div class="container" style="max-width:420px;">
  <div class="card shadow p-4 auth-card">

    <h3 class="text-center mb-2 fw-bold">Login</h3>
    <p class="text-center text-muted mb-4">Internship Management System</p>

    <?php if($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" placeholder="Enter email" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Enter password" required>
      </div>

      <button name="login" class="btn btn-primary w-100">Login</button>
    </form>

    <div class="text-center mt-3">
      <span class="text-muted">Don't have an account?</span>
      <a href="register.php">Register</a>
    </div>

    <div class="text-center mt-2">
      <a href="../index.php" class="small text-decoration-none">← Back to Home</a>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>












