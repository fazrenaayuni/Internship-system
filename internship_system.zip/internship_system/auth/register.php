<?php
session_start();
include("../config/db.php");

$msg = "";

if (isset($_POST['register'])) {

    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];
    $role  = $_POST['user_role'];

    if (empty($name) || empty($email) || empty($pass) || empty($role)) {
        $msg = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "Invalid email format.";
    } else {

        // check email exist
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE user_email=? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $msg = "Email already registered.";
            $stmt->close();
        } else {
            $stmt->close();

            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $status = 'active';

            $stmt = $conn->prepare("
              INSERT INTO users (user_name, user_email, userPass, user_role, status_user)
              VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("sssss", $name, $email, $hash, $role, $status);

            if ($stmt->execute()) {
                $msg = "Registration successful! You can now <a href='login.php'>login</a>.";
            } else {
                $msg = "Registration failed. Please try again.";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/auth.css">
</head>

<body class="auth-bg d-flex align-items-center justify-content-center">

<div class="container" style="max-width:480px;">
  <div class="card shadow p-4 auth-card">

    <h3 class="text-center mb-2 fw-bold">Register</h3>
    <p class="text-center text-muted mb-4">Create your account</p>

    <?php if ($msg): ?>
      <div class="alert alert-info"><?= $msg ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">

      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="name" class="form-control" placeholder="Enter full name" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" placeholder="Enter email" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Create password" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Role</label>
        <select name="user_role" class="form-select" required>
          <option value="">Select Role</option>
          <option value="student">Student</option>
          <option value="staff">Staff</option>
          <option value="admin">Admin</option>
        </select>
      </div>

      <button name="register" class="btn btn-primary w-100">Register</button>
    </form>

    <div class="text-center mt-3">
      <span class="text-muted">Already have account?</span>
      <a href="login.php">Login</a>
    </div>

    <div class="text-center mt-2">
      <a href="../index.php" class="small text-decoration-none">← Back to Home</a>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>














