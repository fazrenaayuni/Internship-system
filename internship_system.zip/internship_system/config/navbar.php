<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include_once __DIR__ . "/db.php";

$user_name = $_SESSION['user_name'] ?? '';
$user_id   = $_SESSION['user_id'] ?? null;
$user_role = $_SESSION['role'] ?? '';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="../dashboard/index.php">Internship System</a>

    <div class="d-flex align-items-center ms-auto gap-2">
      <button id="darkToggle" class="btn btn-outline-light btn-sm">🌙 Dark</button>

      <?php if($user_id): ?>
        <span class="text-white">Welcome, <?= htmlspecialchars($user_name) ?></span>
        <a href="../auth/logout.php" class="btn btn-danger btn-sm">Logout</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<script>
(function(){
  // apply saved mode
  if (localStorage.getItem('darkMode') === 'on') {
    document.body.classList.add('dark-mode');
  }

  document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('darkToggle');
    if(!btn) return;

    btn.addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      localStorage.setItem('darkMode',
        document.body.classList.contains('dark-mode') ? 'on' : 'off'
      );
    });
  });
})();
</script>












