<?php
$role = strtolower($_SESSION['role'] ?? '');
$stats = [];

if($role === 'student'){
    $user_id = $_SESSION['user_id'];
    $stats['total_resumes']  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM resumes WHERE user_id=$user_id"))['total'];
    $stats['pending_apps']   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE user_id=$user_id AND application_status='pending'"))['total'];
    $stats['approved_apps']  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE user_id=$user_id AND application_status='approved'"))['total'];
    $stats['rejected_apps']  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE user_id=$user_id AND application_status='rejected'"))['total'];
} elseif($role === 'staff'){
    $stats['pending_apps']   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='pending'"))['total'];
    $stats['approved_apps']  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='approved'"))['total'];
    $stats['rejected_apps']  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='rejected'"))['total'];
} elseif($role === 'admin'){
    $stats['total_users'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users"))['total'];
    $stats['pending_apps']   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='pending'"))['total'];
    $stats['approved_apps']  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='approved'"))['total'];
    $stats['rejected_apps']  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='rejected'"))['total'];
}
?>
