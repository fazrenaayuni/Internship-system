<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once __DIR__ . "/db.php";

$role = $_SESSION['role'] ?? '';
$bodyClass = 'bg-dashboard';

if ($role === 'admin')   $bodyClass .= ' bg-admin';
if ($role === 'staff')   $bodyClass .= ' bg-staff';
if ($role === 'student') $bodyClass .= ' bg-student';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Internship System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Background CSS -->
  <link rel="stylesheet" href="../assets/css/background.css">
</head>

<body class="<?= $bodyClass ?>">

