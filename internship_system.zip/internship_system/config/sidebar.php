<?php
// make sure session already started in main page
$role    = strtolower($_SESSION['role'] ?? '');
$current = basename($_SERVER['PHP_SELF']);
?>

<div class="col-md-3 mb-4">
  <div class="list-group shadow">

    <!-- ================= ADMIN ================= -->
    <?php if($role === 'admin'): ?>

      <a href="admin.php"
         class="list-group-item list-group-item-action <?= $current=='admin.php'?'active':'' ?>">
        Dashboard
      </a>

      <a href="manage_users.php"
         class="list-group-item list-group-item-action <?= $current=='manage_users.php'?'active':'' ?>">
        Manage Users
      </a>

      <a href="all_applications.php"
         class="list-group-item list-group-item-action <?= $current=='all_applications.php'?'active':'' ?>">
        All Applications
      </a>

      <a href="export_users.php"
         class="list-group-item list-group-item-action <?= $current=='export_users.php'?'active':'' ?>">
        Export Users
      </a>

      <a href="export_applications.php"
         class="list-group-item list-group-item-action <?= $current=='export_applications.php'?'active':'' ?>">
        Export Applications
      </a>

    <!-- ================= STAFF ================= -->
    <?php elseif($role === 'staff'): ?>

      <a href="staff.php"
         class="list-group-item list-group-item-action <?= $current=='staff.php'?'active':'' ?>">
        Dashboard
      </a>

      <!-- ikut file yang memang ada -->
      <a href="staff_pending.php"
         class="list-group-item list-group-item-action <?= $current=='staff_pending.php'?'active':'' ?>">
        Pending Applications
      </a>

      <a href="staff_all.php"
         class="list-group-item list-group-item-action <?= $current=='staff_all.php'?'active':'' ?>">
        All Applications
      </a>

    <!-- ================= STUDENT ================= -->
    <?php elseif($role === 'student'): ?>

      <a href="student.php"
         class="list-group-item list-group-item-action <?= $current=='student.php'?'active':'' ?>">
        Dashboard
      </a>

      <!-- profile.php shared -->
      <a href="profile.php"
         class="list-group-item list-group-item-action <?= $current=='profile.php'?'active':'' ?>">
        My Profile
      </a>

      <!-- guna anchor supaya tak 404 -->
      <a href="student.php#resumes"
         class="list-group-item list-group-item-action">
        My Resumes
      </a>

      <a href="student.php#applications"
         class="list-group-item list-group-item-action">
        My Applications
      </a>

    <?php endif; ?>

    <!-- ================= COMMON (SEMUA ROLE) ================= -->
    <hr class="my-2">

    <a href="announcements.php"
       class="list-group-item list-group-item-action <?= $current=='announcements.php'?'active':'' ?>">
      Announcements
    </a>

    <a href="faq.php"
       class="list-group-item list-group-item-action <?= $current=='faq.php'?'active':'' ?>">
      FAQ
    </a>

    <a href="contact.php"
       class="list-group-item list-group-item-action <?= $current=='contact.php'?'active':'' ?>">
      Contact Us
    </a>

    <a href="../auth/logout.php"
       class="list-group-item list-group-item-action text-danger">
      Logout
    </a>

  </div>
</div>













