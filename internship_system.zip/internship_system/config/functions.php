<?php
include "db.php";
session_start();

// Check login and role
function check_login($role = null){
    if(!isset($_SESSION['user_id'])){
        header("Location: ../auth/login.php");
        exit();
    }
    if($role && $_SESSION['role'] != $role){
        header("Location: ../auth/login.php");
        exit();
    }
}

// Get student resumes
function get_student_resumes($user_id){
    global $conn;
    $resumes = [];
    $sql = "SELECT * FROM resumes WHERE user_id=$user_id ORDER BY created_at DESC";
    $result = mysqli_query($conn, $sql);
    while($row = mysqli_fetch_assoc($result)){
        $resumes[] = $row;
    }
    return $resumes;
}

// Get pending applications (Staff)
function get_pending_applications(){
    global $conn;
    $apps = [];
    $sql = "SELECT a.application_id, a.company_name, a.internship_position, a.application_status,
            r.resume_title, u.user_name
            FROM applications a
            JOIN resumes r ON a.resume_id = r.resume_id
            JOIN users u ON a.user_id = u.user_id
            WHERE a.application_status='pending'
            ORDER BY a.created_at DESC";
    $result = mysqli_query($conn, $sql);
    while($row = mysqli_fetch_assoc($result)){
        $apps[] = $row;
    }
    return $apps;
}

// Get all users (Admin)
function get_all_users(){
    global $conn;
    $users = [];
    $sql = "SELECT * FROM users ORDER BY user_id DESC";
    $result = mysqli_query($conn, $sql);
    while($row = mysqli_fetch_assoc($result)){
        $users[] = $row;
    }
    return $users;
}
?>



