<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student'){
    header("Location: ../auth/login.php");
    exit();
}

$msg = "";

if(isset($_POST['submit'])){
    $user_id = (int)$_SESSION['user_id'];
    $title   = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');

    if($title === ""){
        $msg = "Resume title is required.";
    } else {

        // PDF upload (optional)
        $filePath = null;

        if(isset($_FILES['resume_pdf']) && $_FILES['resume_pdf']['error'] !== UPLOAD_ERR_NO_FILE){

            if($_FILES['resume_pdf']['error'] !== UPLOAD_ERR_OK){
                $msg = "Upload error. Please try again.";
            } else {
                $tmpName = $_FILES['resume_pdf']['tmp_name'];
                $size    = (int)$_FILES['resume_pdf']['size'];
                $ext     = strtolower(pathinfo($_FILES['resume_pdf']['name'], PATHINFO_EXTENSION));

                if($size > 5 * 1024 * 1024){
                    $msg = "File too large. Max 5MB.";
                } elseif($ext !== 'pdf'){
                    $msg = "Only PDF files are allowed.";
                } else {
                    // MIME check
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mime  = finfo_file($finfo, $tmpName);
                    finfo_close($finfo);

                    if($mime !== 'application/pdf'){
                        $msg = "Invalid file type. Please upload a real PDF.";
                    } else {
                        $uploadDir = "../uploads/resumes/";
                        if(!is_dir($uploadDir)){
                            mkdir($uploadDir, 0777, true);
                        }

                        $newName = "resume_" . $user_id . "_" . time() . "_" . bin2hex(random_bytes(4)) . ".pdf";
                        $dest    = $uploadDir . $newName;

                        if(move_uploaded_file($tmpName, $dest)){
                            $filePath = "uploads/resumes/" . $newName; // store relative path
                        } else {
                            $msg = "Failed to save file.";
                        }
                    }
                }
            }
        }

        if($msg === ""){
            $stmt = $conn->prepare("
                INSERT INTO resumes (user_id, resume_title, resume_content, resume_file, resume_status, created_at, updated_at)
                VALUES (?,?,?,?, 'active', NOW(), NOW())
            ");
            $stmt->bind_param("isss", $user_id, $title, $content, $filePath);
            $stmt->execute();
            $stmt->close();

            header("Location: ../dashboard/student.php#resumes");
            exit();
        }
    }
}

include "../config/navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Add Resume</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#ecf0f1;">

<div class="container mt-5" style="max-width:700px;">
  <div class="card shadow">
    <div class="card-header text-white" style="background-color:#2980b9;">Add New Resume</div>
    <div class="card-body">

      <?php if($msg): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
      <?php endif; ?>

      <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label class="form-label">Resume Title</label>
          <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Resume Content (Optional)</label>
          <textarea name="content" class="form-control" rows="4" placeholder="Optional notes..."></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">Upload Resume PDF (Optional)</label>
          <input type="file" name="resume_pdf" class="form-control" accept="application/pdf">
          <small class="text-muted">PDF only, max 5MB.</small>
        </div>

        <button type="submit" name="submit" class="btn btn-primary w-100">Add Resume</button>
      </form>

    </div>
  </div>
</div>

</body>
</html>




