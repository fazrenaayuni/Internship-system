<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'student') {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$result = mysqli_query($conn, "SELECT * FROM resume WHERE user_id=$user_id");
?>

<h3>My Resumes</h3>
<a href="add.php">Add New Resume</a><br><br>
<table border="1" cellpadding="5">
    <tr>
        <th>Title</th>
        <th>Content</th>
        <th>Action</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?= htmlspecialchars($row['resume_title']) ?></td>
        <td><?= htmlspecialchars($row['resume_content']) ?></td>
        <td>
            <a href="delete.php?id=<?= $row['resume_id'] ?>" onclick="return confirm('Delete this resume?')">Delete</a>
        </td>
    </tr>
    <?php } ?>
</table>
