<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student'){
    header("Location: ../auth/login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$id = (int)($_GET['id'] ?? 0);
if($id <= 0) die("Invalid resume.");

$stmt = $conn->prepare("SELECT * FROM resumes WHERE resume_id=? AND user_id=?");
$stmt->bind_param("ii", $id, $user_id);
$stmt->execute();
$resume = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$resume) die("Resume not found.");

$msg = "";

if(isset($_POST['update'])){
    $title   = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');

    if($title === ""){
        $msg = "Resume title is required.";
    } else {

        $newFilePath = $resume['resume_file'] ?? null;

        // Replace PDF if uploaded
        if(isset($_FILES['resume_pdf']) && $_FILES['resume_pdf']['error'] !== UPLOAD_ERR_NO_FILE){

            if($_FILES['resume_pdf']['error'] !== UPLOAD_ERR_OK){
                $msg = "Upload error. Please try again.";
            } else {
                $tmpName = $_FILES['resume_pdf']['tmp_name'];
                $size    = (int)$_FILES['resume_pdf']['size'];
                $ext     = strtolower(pathinfo($_FILES['resume_pdf']['name'], PATHINFO_EXTENSION));

                if($size > 5 * 1024 * 1024){
                    $msg = "File too large. Max 5MB.";
                } elseif($ext !== 'pdf'){
                    $msg = "Only PDF files are allowed.";
                } else {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mime  = finfo_file($finfo, $tmpName);
                    finfo_close($finfo);

                    if($mime !== 'application/pdf'){
                        $msg = "Invalid file type. Please upload a real PDF.";
                    } else {
                        $uploadDir = "../uploads/resumes/";
                        if(!is_dir($uploadDir)){
                            mkdir($uploadDir, 0777, true);
                        }

                        $newName = "resume_" . $user_id . "_" . time() . "_" . bin2hex(random_bytes(4)) . ".pdf";
                        $dest    = $uploadDir . $newName;

                        if(move_uploaded_file($tmpName, $dest)){
                            // delete old file if exists
                            if(!empty($resume['resume_file'])){
                                $oldFull = "../" . $resume['resume_file'];
                                if(file_exists($oldFull)) @unlink($oldFull);
                            }
                            $newFilePath = "uploads/resumes/" . $newName;
                        } else {
                            $msg = "Failed to save file.";
                        }
                    }
                }
            }
        }

        if($msg === ""){
            $stmt2 = $conn->prepare("
                UPDATE resumes
                SET resume_title=?, resume_content=?, resume_file=?, updated_at=NOW()
                WHERE resume_id=? AND user_id=?
            ");
            $stmt2->bind_param("sssii", $title, $content, $newFilePath, $id, $user_id);
            $stmt2->execute();
            $stmt2->close();

            header("Location: ../dashboard/student.php#resumes");
            exit();
        }
    }
}

include "../config/navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Resume</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#ecf0f1;">

<div class="container mt-5" style="max-width:700px;">
  <div class="card shadow">
    <div class="card-header text-white" style="background-color:#c0392b;">Edit Resume</div>
    <div class="card-body">

      <?php if($msg): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
      <?php endif; ?>

      <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label class="form-label">Resume Title</label>
          <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($resume['resume_title']) ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Resume Content (Optional)</label>
          <textarea name="content" class="form-control" rows="4"><?= htmlspecialchars($resume['resume_content'] ?? '') ?></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">Current PDF</label><br>
          <?php if(!empty($resume['resume_file'])): ?>
            <a class="btn btn-sm btn-outline-primary" href="../<?= htmlspecialchars($resume['resume_file']) ?>" target="_blank">View PDF</a>
          <?php else: ?>
            <span class="text-muted">No PDF uploaded.</span>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label class="form-label">Replace PDF (Optional)</label>
          <input type="file" name="resume_pdf" class="form-control" accept="application/pdf">
          <small class="text-muted">PDF only, max 5MB.</small>
        </div>

        <button type="submit" name="update" class="btn btn-danger w-100">Update Resume</button>
        <a href="../dashboard/student.php#resumes" class="btn btn-outline-secondary w-100 mt-2">Back</a>
      </form>

    </div>
  </div>
</div>

</body>
</html>




