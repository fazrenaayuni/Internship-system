<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student'){
    header("Location: ../auth/login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$id = (int)($_GET['id'] ?? 0);

if($id > 0){
    // Get resume_file
    $stmt = $conn->prepare("SELECT resume_file FROM resumes WHERE resume_id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Delete file if exists
    if($res && !empty($res['resume_file'])){
        $full = "../" . $res['resume_file'];
        if(file_exists($full)) @unlink($full);
    }

    // Delete row
    $stmt2 = $conn->prepare("DELETE FROM resumes WHERE resume_id=? AND user_id=?");
    $stmt2->bind_param("ii", $id, $user_id);
    $stmt2->execute();
    $stmt2->close();
}

header("Location: ../dashboard/student.php#resumes");
exit();


