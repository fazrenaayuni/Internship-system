<?php
include "../config/functions.php";
check_login('admin');

// Stats
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users"))['total'];
$pending_apps = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='pending'"))['total'];
$approved_apps = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='approved'"))['total'];
$rejected_apps = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='rejected'"))['total'];

// Chart Data
$chart_labels = json_encode(['Pending', 'Approved', 'Rejected']);
$chart_data = json_encode([$pending_apps, $approved_apps, $rejected_apps]);

// Users Table
$search_user = $_GET['search_user'] ?? '';
$search_user = trim($search_user);
$search_sql_user = $search_user ? " WHERE user_name LIKE '%$search_user%' OR user_email LIKE '%$search_user%'" : "";
$users = mysqli_query($conn, "SELECT * FROM users $search_sql_user ORDER BY created_at DESC");

// Applications Table
$search_app = $_GET['search_app'] ?? '';
$search_app = trim($search_app);
$search_sql_app = $search_app ? " AND (u.user_name LIKE '%$search_app%' OR a.company_name LIKE '%$search_app%')" : "";
$apps = mysqli_query($conn, "SELECT a.application_id, u.user_name, r.resume_title, a.company_name, a.internshio_position, a.application_status 
                            FROM applications a
                            JOIN users u ON a.user_id = u.user_id
                            JOIN resumes r ON a.resume_id = r.resume_id
                            WHERE 1 $search_sql_app
                            ORDER BY a.created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/bg-only.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
.card:hover { transform: translateY(-5px); transition: 0.3s; }

/* ✅ chart kecil */
.chart-wrapper {
  max-width: 320px;
  height: 220px;
  margin: auto;
}
</style>
</head>

<body class="bg-dashboard">

<?php include "../config/navbar.php"; ?>

<div class="container-fluid mt-4">
  <div class="row">

    <!-- Sidebar -->
    <?php include "../config/sidebar.php"; ?>

    <!-- Main Content -->
    <div class="col-md-9">

      <!-- Stats Cards -->
      <div class="row mb-4">
        <div class="col-md-3 mb-3">
          <div class="card text-white bg-primary shadow">
            <div class="card-body">
              <h5 class="card-title">Total Users</h5>
              <p class="card-text fs-3 fw-bold"><?= $total_users ?></p>
            </div>
          </div>
        </div>

        <div class="col-md-3 mb-3">
          <div class="card text-white bg-warning shadow">
            <div class="card-body">
              <h5 class="card-title">Pending Apps</h5>
              <p class="card-text fs-3 fw-bold"><?= $pending_apps ?></p>
            </div>
          </div>
        </div>

        <div class="col-md-3 mb-3">
          <div class="card text-white bg-success shadow">
            <div class="card-body">
              <h5 class="card-title">Approved Apps</h5>
              <p class="card-text fs-3 fw-bold"><?= $approved_apps ?></p>
            </div>
          </div>
        </div>

        <div class="col-md-3 mb-3">
          <div class="card text-white bg-danger shadow">
            <div class="card-body">
              <h5 class="card-title">Rejected Apps</h5>
              <p class="card-text fs-3 fw-bold"><?= $rejected_apps ?></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Chart -->
      <div class="card mb-4 shadow">
        <div class="card-header bg-info text-white">Application Status Overview</div>
        <div class="card-body text-center">
          <!-- ✅ wrapper supaya chart kecik -->
          <div class="chart-wrapper">
            <canvas id="appChart"></canvas>
          </div>
        </div>
      </div>

      <!-- Users Table -->
      <div class="card shadow mb-4">
        <div class="card-header bg-secondary text-white">Manage Users</div>
        <div class="card-body">
          <form method="GET" class="d-flex gap-2 mb-3">
            <input type="text" name="search_user" class="form-control" placeholder="Search users"
                   value="<?= htmlspecialchars($search_user) ?>">
            <button class="btn btn-secondary">Search</button>
          </form>

          <table class="table table-bordered table-striped">
            <thead class="table-light">
              <tr>
                <th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
            <?php if(mysqli_num_rows($users) > 0): ?>
              <?php while($row = mysqli_fetch_assoc($users)): ?>
                <tr>
                  <td><?= htmlspecialchars($row['user_name']) ?></td>
                  <td><?= htmlspecialchars($row['user_email']) ?></td>
                  <td><?= ucfirst($row['user_role']) ?></td>
                  <td><?= ucfirst($row['status_user']) ?></td>
                  <td>
                    <?php if($row['status_user'] != 'active'): ?>
                      <a href="activate_user.php?id=<?= $row['user_id'] ?>" class="btn btn-sm btn-success">Activate</a>
                    <?php endif; ?>
                    <a href="delete_user.php?id=<?= $row['user_id'] ?>" class="btn btn-sm btn-danger"
                       onclick="return confirm('Delete this user?')">Delete</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5" class="text-center">No users found.</td></tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Applications Table -->
      <div class="card shadow mb-4">
        <div class="card-header bg-success text-white">Applications</div>
        <div class="card-body">
          <form method="GET" class="d-flex gap-2 mb-3">
            <input type="text" name="search_app" class="form-control" placeholder="Search applications"
                   value="<?= htmlspecialchars($search_app) ?>">
            <button class="btn btn-secondary">Search</button>
          </form>

          <table class="table table-bordered table-striped">
            <thead class="table-light">
              <tr>
                <th>Student Name</th><th>Resume</th><th>Company</th><th>Position</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if(mysqli_num_rows($apps) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($apps)): ?>
                <tr>
                  <td><?= htmlspecialchars($row['user_name']) ?></td>
                  <td><?= htmlspecialchars($row['resume_title']) ?></td>
                  <td><?= htmlspecialchars($row['company_name']) ?></td>
                  <td><?= htmlspecialchars($row['internshio_position']) ?></td>
                  <td><?= ucfirst($row['application_status']) ?></td>
                </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center">No applications found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</div>

<script>
const ctx = document.getElementById('appChart').getContext('2d');
new Chart(ctx, {
  type: 'pie',
  data: {
    labels: <?= $chart_labels ?>,
    datasets: [{
      data: <?= $chart_data ?>,
      backgroundColor: ['#ffc107','#28a745','#dc3545'],
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false  // ✅ penting supaya ikut wrapper size
  }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>












