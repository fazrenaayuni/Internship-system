<?php
include "../config/functions.php";
check_login('admin');

$id = (int)($_GET['id'] ?? 0);
if($id > 0){
  $stmt = $conn->prepare("UPDATE users SET status_user='inactive' WHERE user_id=?");
  $stmt->bind_param("i",$id);
  $stmt->execute();
  $stmt->close();

  audit_log("deactivate_user", "Deactivated user_id=$id");
}
header("Location: admin.php");
exit();
