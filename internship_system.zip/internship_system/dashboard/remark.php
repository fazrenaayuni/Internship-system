<?php
include "../config/functions.php";
check_login('staff');

$id = (int)($_GET['id'] ?? 0);
if($id <= 0){
  header("Location: remark_list.php");
  exit();
}

$stmt = $conn->prepare("
  SELECT a.application_id, u.user_name, a.company_name, a.internshio_position, a.application_status, a.remark
  FROM applications a
  JOIN users u ON a.user_id=u.user_id
  WHERE a.application_id=?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$app = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$app){
  die("Application not found.");
}

$msg = "";
if(isset($_POST['save'])){
  $remark = trim($_POST['remark'] ?? '');
  $stmt2 = $conn->prepare("UPDATE applications SET remark=?, updated_at=NOW() WHERE application_id=?");
  $stmt2->bind_param("si", $remark, $id);
  $stmt2->execute();
  $stmt2->close();

  $msg = "Remark saved!";
  $app['remark'] = $remark;
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Remark</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background:#f4f6f9;">
<?php include "../config/navbar.php"; ?>

<div class="container mt-4" style="max-width:850px;">
  <div class="card shadow">
    <div class="card-header bg-dark text-white">Edit Remark</div>
    <div class="card-body">

      <?php if($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

      <p><b>Student:</b> <?= htmlspecialchars($app['user_name']) ?></p>
      <p><b>Company:</b> <?= htmlspecialchars($app['company_name']) ?></p>
      <p><b>Position:</b> <?= htmlspecialchars($app['internshio_position']) ?></p>
      <p><b>Status:</b> <?= ucfirst($app['application_status']) ?></p>

      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Remark</label>
          <textarea name="remark" class="form-control" rows="4"><?= htmlspecialchars($app['remark'] ?? '') ?></textarea>
        </div>

        <button class="btn btn-dark" name="save">Save</button>
        <a class="btn btn-outline-secondary" href="remark_list.php">Back</a>
      </form>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


