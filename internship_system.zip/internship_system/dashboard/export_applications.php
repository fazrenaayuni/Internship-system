<?php
include "../config/functions.php";

$role = $_SESSION['role'] ?? '';
if($role !== 'admin' && $role !== 'staff'){
  header("Location: ../auth/login.php"); exit();
}

$search_app = trim($_GET['search_app'] ?? '');
$app_status = trim($_GET['app_status'] ?? '');
$like = "%{$search_app}%";

$where = "WHERE 1";
$params = [];
$types = "";

if($search_app !== ""){
  $where .= " AND (u.user_name LIKE ? OR a.company_name LIKE ?)";
  $params[]=$like; $params[]=$like; $types.="ss";
}
if($app_status !== ""){
  $where .= " AND a.application_status=?";
  $params[]=$app_status; $types.="s";
}

$sql = "
SELECT a.application_id, u.user_name, a.company_name, a.internshio_position, a.application_status,
       a.remark, a.created_at, a.reviewed_at
FROM applications a
JOIN users u ON a.user_id=u.user_id
$where
ORDER BY a.created_at DESC";

$stmt = $conn->prepare($sql);
if(!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=applications_export.csv');

$out = fopen('php://output', 'w');
fputcsv($out, ['application_id','student','company','position','status','remark','created_at','reviewed_at']);

while($row = $res->fetch_assoc()){
  fputcsv($out, $row);
}

fclose($out);
$stmt->close();

audit_log("export_applications", "Exported applications CSV");
exit;
