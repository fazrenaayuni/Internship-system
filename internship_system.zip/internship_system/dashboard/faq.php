<?php
session_start();
include "../config/db.php";

// ✅ any logged-in role can access
if(!isset($_SESSION['user_id'])){
  header("Location: ../auth/login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>FAQ</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/bg-only.css">
</head>

<body class="bg-dashboard">
<?php include "../config/navbar.php"; ?>

<div class="container-fluid mt-4">
  <div class="row">
    <?php include "../config/sidebar.php"; ?>

    <div class="col-md-9">
      <div class="card shadow">
        <div class="card-header bg-dark text-white">Frequently Asked Questions (FAQ)</div>
        <div class="card-body">

          <div class="accordion" id="faqAccordion">

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#q1">
                  How do I update my profile?
                </button>
              </h2>
              <div id="q1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  Go to <b>Profile</b> page from sidebar, edit your details and click <b>Update</b>.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q2">
                  How do students apply for internship?
                </button>
              </h2>
              <div id="q2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  Students can add a resume in <b>My Resumes</b>, then click <b>Apply</b> to submit internship application.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q3">
                  What does staff do in this system?
                </button>
              </h2>
              <div id="q3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  Staff review pending applications and decide to <b>Approve</b> or <b>Reject</b>.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q4">
                  Why can’t I access Admin pages?
                </button>
              </h2>
              <div id="q4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  Admin pages are restricted by role. Only users with <b>Admin</b> role can access those pages.
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
