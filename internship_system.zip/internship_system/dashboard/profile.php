<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$message = "";

// Fetch current user
$stmt = $conn->prepare("SELECT user_name, user_email, user_role, profile_image FROM users WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$user){
    die("User not found.");
}

// Handle Update
if(isset($_POST['update'])){
    $new_name  = trim($_POST['user_name'] ?? '');
    $new_email = trim($_POST['user_email'] ?? '');
    $new_pass  = trim($_POST['password'] ?? '');

    if($new_name === "" || $new_email === ""){
        $message = "Name & Email are required.";
    } elseif(!filter_var($new_email, FILTER_VALIDATE_EMAIL)){
        $message = "Invalid email format.";
    } else {

        // Check email duplicate except current user
        $stmtC = $conn->prepare("SELECT user_id FROM users WHERE user_email=? AND user_id<>?");
        $stmtC->bind_param("si", $new_email, $user_id);
        $stmtC->execute();
        $dup = $stmtC->get_result()->fetch_assoc();
        $stmtC->close();

        if($dup){
            $message = "Email already used by another account.";
        } else {

            // ====== Upload Profile Image (optional) ======
            $image_path = $user['profile_image']; // existing

            if(isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE){

                if($_FILES['profile_image']['error'] !== UPLOAD_ERR_OK){
                    $message = "Image upload error.";
                } else {
                    $tmpName = $_FILES['profile_image']['tmp_name'];
                    $size    = (int)$_FILES['profile_image']['size'];
                    $ext     = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));

                    // limit 2MB
                    if($size > 2 * 1024 * 1024){
                        $message = "Image too large. Max 2MB.";
                    } elseif(!in_array($ext, ['jpg','jpeg','png'])){
                        $message = "Only JPG, JPEG, PNG allowed.";
                    } else {
                        // Ensure folder exists
                        $dir = __DIR__ . "/../uploads/profile/";
                        if(!is_dir($dir)){
                            mkdir($dir, 0777, true);
                        }

                        $newName = "user_" . $user_id . "_" . time() . "_" . bin2hex(random_bytes(3)) . "." . $ext;
                        $dest = $dir . $newName;

                        if(move_uploaded_file($tmpName, $dest)){
                            // delete old image
                            if(!empty($image_path)){
                                $old = __DIR__ . "/../" . $image_path;
                                if(file_exists($old)) @unlink($old);
                            }
                            $image_path = "uploads/profile/" . $newName;
                        } else {
                            $message = "Failed to save image. Check folder uploads/profile exists.";
                        }
                    }
                }
            }

            // ====== Update DB ======
            if($message === ""){
                if($new_pass !== ""){
                    $hash = password_hash($new_pass, PASSWORD_DEFAULT);
                    $stmtU = $conn->prepare("UPDATE users SET user_name=?, user_email=?, userPass=?, profile_image=? WHERE user_id=?");
                    $stmtU->bind_param("ssssi", $new_name, $new_email, $hash, $image_path, $user_id);
                } else {
                    $stmtU = $conn->prepare("UPDATE users SET user_name=?, user_email=?, profile_image=? WHERE user_id=?");
                    $stmtU->bind_param("sssi", $new_name, $new_email, $image_path, $user_id);
                }

                if($stmtU->execute()){
                    $message = "Profile updated successfully.";
                    // update session
                    $_SESSION['user_name'] = $new_name;
                    $_SESSION['role'] = $user['user_role']; // keep
                    $_SESSION['profile_image'] = $image_path;

                    // update local
                    $user['user_name'] = $new_name;
                    $user['user_email'] = $new_email;
                    $user['profile_image'] = $image_path;
                } else {
                    $message = "Update failed. Please try again.";
                }
                $stmtU->close();
            }
        }
    }
}

// Determine dashboard back link by role
$role = strtolower($user['user_role'] ?? ($_SESSION['role'] ?? ''));
$back = "index.php";
if($role === "student") $back = "student.php";
if($role === "staff")   $back = "staff.php";
if($role === "admin")   $back = "admin.php";

// Default image
$displayImg = !empty($user['profile_image']) ? "../".$user['profile_image'] : "../assets/default-user.png";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Profile</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#f4f6f9;">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= htmlspecialchars($back) ?>">Internship System</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item">
          <a href="<?= htmlspecialchars($back) ?>" class="btn btn-outline-light">Back Dashboard</a>
        </li>
        <li class="nav-item">
          <a href="../auth/logout.php" class="btn btn-danger ms-2">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4" style="max-width:650px;">
  <div class="card shadow">
    <div class="card-header bg-primary text-white">
      My Profile (<?= htmlspecialchars(ucfirst($role)) ?>)
    </div>
    <div class="card-body">

      <?php if($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
      <?php endif; ?>

      <form method="POST" enctype="multipart/form-data">
        <div class="text-center mb-3">
          <img src="<?= htmlspecialchars($displayImg) ?>" class="rounded-circle"
               style="width:130px;height:130px;object-fit:cover;border:3px solid #eee;">
        </div>

        <div class="mb-3">
          <label class="form-label">Profile Picture (JPG/PNG max 2MB)</label>
          <input type="file" name="profile_image" class="form-control" accept="image/png,image/jpeg">
        </div>

        <div class="mb-3">
          <label class="form-label">Name</label>
          <input type="text" name="user_name" class="form-control" value="<?= htmlspecialchars($user['user_name']) ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" name="user_email" class="form-control" value="<?= htmlspecialchars($user['user_email']) ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">New Password (optional)</label>
          <input type="password" name="password" class="form-control" placeholder="Leave blank if no change">
        </div>

        <button type="submit" name="update" class="btn btn-primary w-100">Update Profile</button>
      </form>

    </div>
  </div>
</div>

</body>
</html>


