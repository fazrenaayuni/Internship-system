<?php
include "../config/functions.php";
check_login('staff');

$id = (int)($_GET['id'] ?? 0);
if($id > 0){
  $stmt = $conn->prepare("UPDATE applications SET application_status='approved', updated_at=NOW() WHERE application_id=?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $stmt->close();
}
header("Location: staff_pending.php");
exit();





