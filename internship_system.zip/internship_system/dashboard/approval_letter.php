<?php
// dashboard/approval_letter.php
session_start();
require_once __DIR__ . '/../config/db.php';

// =====================
// 1) CHECK LOGIN
// =====================
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = (int)($_SESSION['user_id'] ?? 0);
$role    = strtolower($_SESSION['role'] ?? '');

// =====================
// 2) GET application_id (support many param names)
// =====================
$app_id = 0;

if (isset($_GET['application_id'])) {
    $app_id = (int)$_GET['application_id'];
} elseif (isset($_GET['applicationId'])) {
    $app_id = (int)$_GET['applicationId'];
} elseif (isset($_GET['id'])) {
    $app_id = (int)$_GET['id'];
}

if ($app_id <= 0) {
    // bagi message jelas + contoh URL
    die("Invalid application_id. Contoh URL: approval_letter.php?application_id=1");
}

// =====================
// 3) LOAD FPDF (ikut folder kau)
// Kau tunjuk folder: config/lib/fpdf.php
// =====================
$fpdf_path = __DIR__ . '/../config/lib/fpdf.php';
if (!file_exists($fpdf_path)) {
    die("FPDF file tak jumpa: " . $fpdf_path . " (pastikan fpdf.php ada dalam config/lib/)");
}
require_once $fpdf_path;

// =====================
// 4) GET APPLICATION INFO
// NOTE: ikut DB kau: internshio_position
// =====================
$sql = "
SELECT
    a.application_id,
    a.user_id,
    a.company_name,
    a.internshio_position,
    a.application_status,
    a.created_at,
    u.user_name,
    u.user_email,
    r.resume_title
FROM applications a
JOIN users u ON a.user_id = u.user_id
JOIN resumes r ON a.resume_id = r.resume_id
WHERE a.application_id = ?
LIMIT 1
";

$stmt = $conn->prepare($sql);
if (!$stmt) die("Prepare failed: " . $conn->error);

$stmt->bind_param("i", $app_id);
$stmt->execute();
$res = $stmt->get_result();
$app = $res->fetch_assoc();
$stmt->close();

if (!$app) {
    die("Application not found.");
}

// =====================
// 5) SECURITY RULE
// Student boleh generate surat untuk dia je
// Staff/Admin boleh semua
// =====================
if ($role === 'student' && (int)$app['user_id'] !== $user_id) {
    die("Access denied.");
}

// =====================
// 6) ONLY APPROVED CAN GENERATE
// =====================
if (strtolower($app['application_status']) !== 'approved') {
    die("Surat hanya boleh dijana bila status = Approved.");
}

// =====================
// 7) HELPERS (FPDF not full UTF-8)
// =====================
function pdf_text($txt){
    return iconv('UTF-8', 'windows-1252//TRANSLIT', (string)$txt);
}

// =====================
// 8) GENERATE PDF
// =====================
$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 20);

// Header
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10, pdf_text('INTERNSHIP MANAGEMENT SYSTEM'), 0, 1, 'C');

$pdf->SetFont('Arial','',10);
$pdf->Cell(0,6, pdf_text('Approval Letter'), 0, 1, 'C');

$pdf->Ln(5);
$pdf->Line(10, 30, 200, 30);
$pdf->Ln(10);

// Date
$pdf->SetFont('Arial','',11);
$pdf->Cell(0,6, pdf_text('Date: ' . date('d M Y')), 0, 1, 'R');
$pdf->Ln(6);

// Student details
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,7, pdf_text("Student Details"), 0, 1);

$pdf->SetFont('Arial','',11);
$pdf->Cell(45,7, pdf_text("Name"), 0, 0);
$pdf->Cell(0,7, pdf_text(": " . $app['user_name']), 0, 1);

$pdf->Cell(45,7, pdf_text("Email"), 0, 0);
$pdf->Cell(0,7, pdf_text(": " . $app['user_email']), 0, 1);

$pdf->Cell(45,7, pdf_text("Resume"), 0, 0);
$pdf->Cell(0,7, pdf_text(": " . $app['resume_title']), 0, 1);

$pdf->Ln(5);

// Internship details
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,7, pdf_text("Internship Details"), 0, 1);

$pdf->SetFont('Arial','',11);
$pdf->Cell(45,7, pdf_text("Company"), 0, 0);
$pdf->Cell(0,7, pdf_text(": " . $app['company_name']), 0, 1);

$pdf->Cell(45,7, pdf_text("Position"), 0, 0);
$pdf->Cell(0,7, pdf_text(": " . $app['internshio_position']), 0, 1);

$pdf->Cell(45,7, pdf_text("Application ID"), 0, 0);
$pdf->Cell(0,7, pdf_text(": " . $app['application_id']), 0, 1);

$pdf->Cell(45,7, pdf_text("Status"), 0, 0);
$pdf->Cell(0,7, pdf_text(": " . ucfirst($app['application_status'])), 0, 1);

$pdf->Ln(10);

// Body
$pdf->SetFont('Arial','',11);
$body =
"Dear {$app['user_name']},\n\n"
."Congratulations! Your internship application has been APPROVED.\n\n"
."You are approved to undergo internship at:\n"
."Company: {$app['company_name']}\n"
."Position: {$app['internshio_position']}\n\n"
."Please contact the company for further instructions.\n\n"
."Thank you.\n\n"
."Sincerely,\n"
."Internship System Administration";

$pdf->MultiCell(0,6, pdf_text($body), 0, 'L');

$pdf->Ln(15);
$pdf->Cell(0,6, pdf_text("______________________________"), 0, 1, 'L');
$pdf->Cell(0,6, pdf_text("Authorized Signature"), 0, 1, 'L');

$pdf->Ln(5);
$pdf->SetFont('Arial','I',9);
$pdf->MultiCell(0,5, pdf_text("Note: This letter is auto-generated by Internship Management System."), 0, 'L');

// =====================
// 9) FORCE DOWNLOAD
// =====================
$filename = "Approval_Letter_AppID_" . $app['application_id'] . ".pdf";
$pdf->Output('D', $filename);
exit;
