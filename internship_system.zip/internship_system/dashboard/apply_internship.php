<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$resume_id = (int)($_GET['resume_id'] ?? ($_POST['resume_id'] ?? 0));

if ($resume_id <= 0) {
    die("Invalid resume.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $company_name    = trim($_POST['company_name'] ?? '');
    $company_address = trim($_POST['company_address'] ?? '');
    $company_email   = trim($_POST['company_email'] ?? '');
    $position        = trim($_POST['position'] ?? '');

    if ($company_name === '' || $company_address === '' || $company_email === '' || $position === '') {
        $error = "All fields are required.";
    } else {

        $stmt = $conn->prepare("
            INSERT INTO applications
            (user_id, resume_id, company_name, company_address, company_email, internshio_position, application_status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW(), NOW())
        ");

        $stmt->bind_param(
            "iissss",
            $user_id,
            $resume_id,
            $company_name,
            $company_address,
            $company_email,
            $position
        );

        if ($stmt->execute()) {
            $stmt->close();
            header("Location: student.php");
            exit();
        } else {
            $error = "Failed to submit application.";
            $stmt->close();
        }
    }
}

$res = $conn->query("SELECT resume_title FROM resumes WHERE resume_id=$resume_id AND user_id=$user_id");
$resume = $res ? $res->fetch_assoc() : null;

if (!$resume) {
    die("Resume not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Apply Internship</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background:#f4f6f9;">

<div class="container mt-5" style="max-width:650px;">
    <div class="card shadow">
        <div class="card-header bg-success text-white">
            Apply Internship (<?= htmlspecialchars($resume['resume_title']) ?>)
        </div>

        <div class="card-body">

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="resume_id" value="<?= $resume_id ?>">

                <div class="mb-3">
                    <label class="form-label">Company Name</label>
                    <input type="text" name="company_name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Company Address</label>
                    <textarea name="company_address" class="form-control" rows="3" required></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Company Email</label>
                    <input type="email" name="company_email" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Internship Position</label>
                    <input type="text" name="position" class="form-control" required>
                </div>

                <button class="btn btn-success w-100">Submit Application</button>
                <a href="student.php" class="btn btn-outline-secondary w-100 mt-2">Back</a>
            </form>

        </div>
    </div>
</div>

</body>
</html>
