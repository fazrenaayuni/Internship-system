<?php
include "../config/functions.php";
check_login('admin'); // hanya admin boleh masuk

// GET filters
$search_user    = trim($_GET['search_user'] ?? '');
$filter_status  = strtolower(trim($_GET['status'] ?? 'all')); // all|active|inactive
$filter_role    = strtolower(trim($_GET['role'] ?? 'all'));   // all|student|staff|admin

// Kalau user type "active" / "inactive" dekat search, auto set filter status (optional)
if (strtolower($search_user) === "active")   $filter_status = "active";
if (strtolower($search_user) === "inactive") $filter_status = "inactive";

// Build WHERE with prepared statement
$conditions = [];
$params = [];
$types = "";

// Search name/email
if ($search_user !== "") {
    $conditions[] = "(user_name LIKE ? OR user_email LIKE ?)";
    $like = "%{$search_user}%";
    $params[] = $like; $types .= "s";
    $params[] = $like; $types .= "s";
}

// Filter status
if (in_array($filter_status, ["active", "inactive"], true)) {
    $conditions[] = "LOWER(status_user) = ?";
    $params[] = $filter_status; $types .= "s";
}

// Filter role
if (in_array($filter_role, ["admin", "staff", "student"], true)) {
    $conditions[] = "LOWER(user_role) = ?";
    $params[] = $filter_role; $types .= "s";
}

$where = "";
if (count($conditions) > 0) {
    $where = "WHERE " . implode(" AND ", $conditions);
}

// Query users
$sql = "SELECT user_id, user_name, user_email, user_role, status_user, created_at
        FROM users
        $where
        ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$users = $stmt->get_result(); // perlukan mysqlnd (Laragon biasa ada)

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Users</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#f4f6f9; }
    .card { border:0; }
  </style>
</head>
<body>

<?php include "../config/navbar.php"; ?>

<div class="container-fluid mt-4">
  <div class="row">

    <!-- Sidebar -->
    <?php include "../config/sidebar.php"; ?>

    <!-- Content -->
    <div class="col-md-9">
      <div class="card shadow mb-4">
        <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
          <span>Manage Users</span>
        </div>

        <div class="card-body">

          <!-- FILTER FORM -->
          <form method="GET" class="row g-2 align-items-end mb-3">
            <div class="col-md-5">
              <label class="form-label">Search (Name / Email)</label>
              <input type="text" name="search_user" class="form-control"
                     placeholder="e.g. Ali / gmail.com / active"
                     value="<?= htmlspecialchars($search_user) ?>">
            </div>

            <div class="col-md-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <option value="all" <?= $filter_status=='all' ? 'selected' : '' ?>>All Status</option>
                <option value="active" <?= $filter_status=='active' ? 'selected' : '' ?>>Active</option>
                <option value="inactive" <?= $filter_status=='inactive' ? 'selected' : '' ?>>Inactive</option>
              </select>
            </div>

            <div class="col-md-3">
              <label class="form-label">Role</label>
              <select name="role" class="form-select">
                <option value="all" <?= $filter_role=='all' ? 'selected' : '' ?>>All Roles</option>
                <option value="student" <?= $filter_role=='student' ? 'selected' : '' ?>>Student</option>
                <option value="staff" <?= $filter_role=='staff' ? 'selected' : '' ?>>Staff</option>
                <option value="admin" <?= $filter_role=='admin' ? 'selected' : '' ?>>Admin</option>
              </select>
            </div>

            <div class="col-md-1 d-grid">
              <button class="btn btn-secondary">Filter</button>
            </div>
          </form>

          <!-- USERS TABLE -->
          <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
              <thead class="table-light">
                <tr>
                  <th width="25%">Name</th>
                  <th>Email</th>
                  <th width="12%">Role</th>
                  <th width="12%">Status</th>
                  <th width="22%">Actions</th>
                </tr>
              </thead>
              <tbody>
              <?php if($users && $users->num_rows > 0): ?>
                <?php while($row = $users->fetch_assoc()): ?>
                  <?php
                    $uid = (int)$row['user_id'];
                    $status = strtolower($row['status_user'] ?? '');
                  ?>
                  <tr>
                    <td><?= htmlspecialchars($row['user_name']) ?></td>
                    <td><?= htmlspecialchars($row['user_email']) ?></td>
                    <td><?= ucfirst(htmlspecialchars($row['user_role'])) ?></td>
                    <td>
                      <?php if($status === 'active'): ?>
                        <span class="badge bg-success">Active</span>
                      <?php else: ?>
                        <span class="badge bg-danger">Inactive</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($status === 'active'): ?>
                        <a href="deactivate_user.php?id=<?= $uid ?>" class="btn btn-sm btn-warning"
                           onclick="return confirm('Deactivate this user?')">Deactivate</a>
                      <?php else: ?>
                        <a href="activate_user.php?id=<?= $uid ?>" class="btn btn-sm btn-success"
                           onclick="return confirm('Activate this user?')">Activate</a>
                      <?php endif; ?>

                      <a href="delete_user.php?id=<?= $uid ?>" class="btn btn-sm btn-danger"
                         onclick="return confirm('Delete this user?')">Delete</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="5" class="text-center text-muted">No users found.</td>
                </tr>
              <?php endif; ?>
              </tbody>
            </table>
          </div>

        </div>
      </div>

      <?php
        // Close stmt selepas dah habis output table (elak error "stmt already closed")
        if ($stmt) $stmt->close();
      ?>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
