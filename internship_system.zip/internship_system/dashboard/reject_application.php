<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff'){
    header("Location: ../auth/login.php");
    exit();
}

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $stmt = mysqli_prepare($conn, "UPDATE applications SET application_status='rejected', updated_at=NOW() WHERE application_id=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

header("Location: staff.php");
exit();


