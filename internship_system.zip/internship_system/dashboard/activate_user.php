<?php
include "../config/functions.php";
check_login('admin');

$id = (int)($_GET['id'] ?? 0);
if($id > 0){
  $stmt = $conn->prepare("UPDATE users SET status_user='active' WHERE user_id=?");
  $stmt->bind_param("i",$id);
  $stmt->execute();
  $stmt->close();

  audit_log("activate_user", "Activated user_id=$id");
}
header("Location: admin.php");
exit();



