<?php
session_start();
include "../config/db.php";

// login check
if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
    exit();
}

$role = strtolower($_SESSION['role'] ?? '');
$msg  = "";

// =========================
// POST ANNOUNCEMENT (ADMIN)
// =========================
if($role === 'admin' && isset($_POST['post_announcement'])){
    $title = trim($_POST['title'] ?? '');
    $body  = trim($_POST['body'] ?? '');

    if($title === "" || $body === ""){
        $msg = "Please fill in announcement title and message.";
    } else {
        $stmt = $conn->prepare("
            INSERT INTO announcements (announcement_title, ann_body, created_by, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->bind_param("ssi", $title, $body, $_SESSION['user_id']);

        if($stmt->execute()){
            $msg = "✅ Announcement posted successfully!";
        } else {
            $msg = "❌ Failed to post announcement. Please try again.";
        }

        $stmt->close();
    }
}

// =========================
// DELETE ANNOUNCEMENT (ADMIN)
// =========================
if($role === 'admin' && isset($_GET['delete_id'])){
    $delete_id = (int)$_GET['delete_id'];

    $stmt = $conn->prepare("DELETE FROM announcements WHERE ann_id=?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();

    header("Location: announcements.php");
    exit();
}

// =========================
// FETCH ANNOUNCEMENTS
// =========================
$search = trim($_GET['search'] ?? '');
$announcements = [];

if($search !== ""){
    $like = "%".$search."%";
    $stmt = $conn->prepare("
        SELECT a.ann_id, a.announcement_title, a.ann_body, a.created_at, u.user_name
        FROM announcements a
        JOIN users u ON a.created_by = u.user_id
        WHERE a.announcement_title LIKE ? OR a.ann_body LIKE ? OR u.user_name LIKE ?
        ORDER BY a.created_at DESC
    ");
    $stmt->bind_param("sss", $like, $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()){
        $announcements[] = $row;
    }
    $stmt->close();
} else {
    $result = $conn->query("
        SELECT a.ann_id, a.announcement_title, a.ann_body, a.created_at, u.user_name
        FROM announcements a
        JOIN users u ON a.created_by = u.user_id
        ORDER BY a.created_at DESC
    ");
    while($row = $result->fetch_assoc()){
        $announcements[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Announcements</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body{ background:#f4f6f9; }
    .card-hover:hover{ transform: translateY(-2px); transition: .2s; }
</style>
</head>

<body>
<?php include "../config/navbar.php"; ?>

<div class="container-fluid mt-4">
  <div class="row">

    <!-- Sidebar -->
    <?php include "../config/sidebar.php"; ?>

    <!-- Content -->
    <div class="col-md-9">

      <div class="card shadow mb-4">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
          <div>Announcements</div>
          <small class="opacity-75">Visible to Admin / Staff / Student</small>
        </div>

        <div class="card-body">

          <?php if($msg): ?>
            <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
          <?php endif; ?>

          <!-- Search -->
          <form method="GET" class="d-flex mb-3">
            <input type="text" name="search" class="form-control me-2"
                   placeholder="Search title/message/poster..."
                   value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-secondary">Search</button>
            <?php if($search !== ""): ?>
              <a href="announcements.php" class="btn btn-outline-secondary ms-2">Reset</a>
            <?php endif; ?>
          </form>

          <!-- ADMIN POST FORM -->
          <?php if($role === 'admin'): ?>
            <div class="card mb-4 shadow-sm">
              <div class="card-header bg-light"><b>Post New Announcement</b></div>
              <div class="card-body">
                <form method="POST">
                  <div class="mb-2">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" required>
                  </div>
                  <div class="mb-2">
                    <label class="form-label">Message</label>
                    <textarea name="body" class="form-control" rows="4" required></textarea>
                  </div>
                  <button name="post_announcement" class="btn btn-primary">Post</button>
                </form>
              </div>
            </div>
          <?php endif; ?>

          <!-- ANNOUNCEMENT LIST -->
          <?php if(count($announcements) === 0): ?>
            <div class="text-center text-muted p-4">
              No announcements found.
            </div>
          <?php else: ?>
            <?php foreach($announcements as $a): ?>
              <div class="card mb-3 shadow-sm card-hover">
                <div class="card-body">
                  <div class="d-flex justify-content-between align-items-start">
                    <h5 class="mb-1"><?= htmlspecialchars($a['announcement_title']) ?></h5>

                    <?php if($role === 'admin'): ?>
                      <a class="btn btn-sm btn-danger"
                         onclick="return confirm('Delete this announcement?')"
                         href="announcements.php?delete_id=<?= (int)$a['ann_id'] ?>">
                         Delete
                      </a>
                    <?php endif; ?>
                  </div>

                  <div class="text-muted mb-2">
                    Posted by <b><?= htmlspecialchars($a['user_name']) ?></b>
                    • <?= htmlspecialchars($a['created_at']) ?>
                  </div>

                  <div><?= nl2br(htmlspecialchars($a['ann_body'])) ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>

        </div>
      </div>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
