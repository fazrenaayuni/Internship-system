<?php
session_start();
include "../config/db.php";

// ✅ any logged-in role can access
if(!isset($_SESSION['user_id'])){
  header("Location: ../auth/login.php");
  exit();
}

$msg = "";

// Optional: simple form (tak simpan DB, just demo)
if(isset($_POST['send'])){
  $subject = trim($_POST['subject'] ?? '');
  $message = trim($_POST['message'] ?? '');

  if($subject === "" || $message === ""){
    $msg = "Please fill in all fields.";
  } else {
    $msg = "Message sent successfully! (Demo only)";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Contact Us</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/bg-only.css">
</head>

<body class="bg-dashboard">
<?php include "../config/navbar.php"; ?>

<div class="container-fluid mt-4">
  <div class="row">
    <?php include "../config/sidebar.php"; ?>

    <div class="col-md-9">
      <div class="card shadow">
        <div class="card-header bg-dark text-white">Contact Us</div>
        <div class="card-body">

          <?php if($msg): ?>
            <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
          <?php endif; ?>

          <div class="row g-4">
            <div class="col-md-5">
              <h5>Support Information</h5>
              <p class="text-muted mb-2">Internship Management System</p>
              <p class="mb-1"><b>Email:</b> support@internship-system.com</p>
              <p class="mb-1"><b>Phone:</b> +60 12-345 6789</p>
              <p class="mb-1"><b>Office Hours:</b> Mon–Fri, 9AM–5PM</p>
              <p class="mb-0"><b>Location:</b> Malaysia</p>
            </div>

            <div class="col-md-7">
              <h5>Send us a message</h5>
              <form method="POST" class="mt-3">
                <div class="mb-3">
                  <label class="form-label">Subject</label>
                  <input type="text" name="subject" class="form-control" placeholder="Enter subject" required>
                </div>

                <div class="mb-3">
                  <label class="form-label">Message</label>
                  <textarea name="message" class="form-control" rows="5" placeholder="Type your message..." required></textarea>
                </div>

                <button name="send" class="btn btn-primary">Send Message</button>
              </form>
            </div>
          </div>

        </div>
      </div>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
