<?php
session_start();
include "../config/db.php";

// Only student
if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student'){
    header("Location: ../auth/login.php");
    exit();
}

// Fetch student info
$stmt = $conn->prepare("SELECT user_name, user_role FROM users WHERE user_id=?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result_user = $stmt->get_result();
$user = $result_user->fetch_assoc();
$student_name = $user['user_name'] ?? 'Student';
$student_role = ucfirst($user['user_role'] ?? 'Student');
$stmt->close();

$user_id = (int)$_SESSION['user_id'];

// Search resumes
$search = $_GET['search'] ?? '';
$search_safe = mysqli_real_escape_string($conn, $search);
$search_sql = $search ? "AND resume_title LIKE '%$search_safe%'" : "";

// Fetch resumes
$resumes = mysqli_query($conn, "SELECT * FROM resumes WHERE user_id=$user_id $search_sql ORDER BY created_at DESC");

// Stats
$total_resumes = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM resumes WHERE user_id=$user_id"))['total'];
$pending_apps  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE user_id=$user_id AND application_status='pending'"))['total'];
$approved_apps = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE user_id=$user_id AND application_status='approved'"))['total'];
$rejected_apps = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE user_id=$user_id AND application_status='rejected'"))['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#f4f6f9;">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="student.php">Internship System</a>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item">
          <span class="nav-link text-white">Welcome, <?= htmlspecialchars($student_name) ?> (<?= htmlspecialchars($student_role) ?>)</span>
        </li>
        <li class="nav-item">
          <a href="../auth/logout.php" class="btn btn-danger ms-2">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid mt-4">
  <div class="row">

    <!-- Sidebar -->
    <div class="col-md-3 mb-4">
      <div class="list-group shadow">
        <a href="student.php" class="list-group-item list-group-item-action active">Dashboard</a>
        <a href="profile.php" class="list-group-item list-group-item-action">Profile</a>
        <a href="#resumes" class="list-group-item list-group-item-action">My Resumes</a>
        <a href="#applications" class="list-group-item list-group-item-action">My Applications</a>
        <a href="announcements.php" class="list-group-item list-group-item-action">Announcements</a>
        <a href="faq.php" class="list-group-item list-group-item-action">FAQ</a>
        <a href="contact.php" class="list-group-item list-group-item-action">Contact Us</a>
      </div>
    </div>

    <!-- Main Content -->
    <div class="col-md-9">

      <!-- Stats Cards -->
      <div class="row mb-4">
        <div class="col-md-3 mb-3">
          <div class="card text-white bg-primary shadow">
            <div class="card-body">
              <h5 class="card-title">Total Resumes</h5>
              <p class="card-text fs-3 fw-bold"><?= $total_resumes ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-white bg-warning shadow">
            <div class="card-body">
              <h5 class="card-title">Pending Apps</h5>
              <p class="card-text fs-3 fw-bold"><?= $pending_apps ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-white bg-success shadow">
            <div class="card-body">
              <h5 class="card-title">Approved Apps</h5>
              <p class="card-text fs-3 fw-bold"><?= $approved_apps ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-white bg-danger shadow">
            <div class="card-body">
              <h5 class="card-title">Rejected Apps</h5>
              <p class="card-text fs-3 fw-bold"><?= $rejected_apps ?></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Resumes Table -->
      <div class="card shadow mb-4" id="resumes">
        <div class="card-header bg-secondary text-white">My Resumes</div>
        <div class="card-body">

          <a href="../resume/add_resume.php" class="btn btn-primary mb-3">Add Resume</a>

          <form method="GET" class="d-flex mb-3">
            <input type="text" name="search" class="form-control me-2" placeholder="Search resume title"
                   value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-secondary">Search</button>
          </form>

          <table class="table table-bordered table-striped">
            <thead class="table-light">
              <tr>
                <th>Title</th>
                <th>Content</th>
                <th width="35%">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if(mysqli_num_rows($resumes) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($resumes)): ?>
                  <tr>
                    <td><?= htmlspecialchars($row['resume_title']) ?></td>
                    <td><?= htmlspecialchars($row['resume_content']) ?></td>
                    <td>
                      <a href="../resume/edit_resume.php?id=<?= $row['resume_id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                      <a href="../resume/delete_resume.php?id=<?= $row['resume_id'] ?>" class="btn btn-sm btn-danger"
                         onclick="return confirm('Delete this resume?')">Delete</a>
                      <a href="../dashboard/apply_internship.php?resume_id=<?= $row['resume_id'] ?>" class="btn btn-sm btn-success">Apply</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="3" class="text-center text-muted">No resumes found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Applications Section -->
      <div class="card shadow mb-4" id="applications">
        <div class="card-header bg-success text-white">My Applications</div>
        <div class="card-body">
          <?php
          $apps = mysqli_query($conn, "SELECT a.application_id, a.company_name, a.internshio_position, a.application_status, r.resume_title 
                                      FROM applications a 
                                      JOIN resumes r ON a.resume_id=r.resume_id 
                                      WHERE a.user_id=$user_id ORDER BY a.created_at DESC");
          ?>
          <table class="table table-bordered table-striped">
            <thead class="table-light">
              <tr>
                <th>Resume</th>
                <th>Company</th>
                <th>Position</th>
                <th>Status</th>
                <th>Letter (PDF)</th>
              </tr>
            </thead>
            <tbody>
              <?php if(mysqli_num_rows($apps) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($apps)): ?>
                  <tr>
                    <td><?= htmlspecialchars($row['resume_title']) ?></td>
                    <td><?= htmlspecialchars($row['company_name']) ?></td>
                    <td><?= htmlspecialchars($row['internshio_position']) ?></td>
                    <td><?= ucfirst($row['application_status']) ?></td>
                    <td>
                      <?php if($row['application_status'] === 'approved'): ?>
                        <a href="approval_letter.php?id=<?= $row['application_id'] ?>" class="btn btn-sm btn-dark">
                          Download PDF
                        </a>
                      <?php else: ?>
                        <span class="text-muted">-</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted">No applications found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>

          <small class="text-muted">
            PDF approval letter is available only for <b>Approved</b> applications.
          </small>

        </div>
      </div>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>














