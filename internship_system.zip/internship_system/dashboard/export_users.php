<?php
include "../config/functions.php";
check_login('admin');

$search_user = trim($_GET['search_user'] ?? '');
$filter_role = trim($_GET['filter_role'] ?? '');
$filter_status = trim($_GET['filter_status'] ?? '');

$where = "WHERE 1";
$params = [];
$types = "";

if($search_user !== ""){
  $where .= " AND (user_name LIKE ? OR user_email LIKE ?)";
  $params[]="%{$search_user}%"; $params[]="%{$search_user}%";
  $types.="ss";
}
if($filter_role !== ""){
  $where .= " AND user_role=?";
  $params[]=$filter_role; $types.="s";
}
if($filter_status !== ""){
  $where .= " AND status_user=?";
  $params[]=$filter_status; $types.="s";
}

$sql = "SELECT user_id, user_name, user_email, user_role, status_user, created_at FROM users $where ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
if(!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=users_export.csv');

$out = fopen('php://output', 'w');
fputcsv($out, ['user_id','name','email','role','status','created_at']);

while($row = $res->fetch_assoc()){
  fputcsv($out, $row);
}

fclose($out);
$stmt->close();

audit_log("export_users", "Exported users CSV");
exit;

