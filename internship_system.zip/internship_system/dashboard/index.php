<?php
session_start();

if(!isset($_SESSION['role'])){
    header("Location: ../auth/login.php");
    exit();
}

switch($_SESSION['role']){
    case 'student':
        header("Location: student.php"); break;
    case 'staff':
        header("Location: staff.php"); break;
    case 'admin':
        header("Location: admin.php"); break;
    default:
        header("Location: ../auth/login.php"); break;
}
exit();

