<?php
include "../config/functions.php";
check_login('admin');

// FILTER
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

$search = trim($search);
$status = trim($status);

// Base SQL (Prepared)
$sql = "SELECT 
            a.application_id,
            u.user_name,
            r.resume_title,
            a.company_name,
            a.internshio_position,
            a.application_status,
            a.created_at
        FROM applications a
        JOIN users u ON a.user_id = u.user_id
        JOIN resumes r ON a.resume_id = r.resume_id
        WHERE 1 ";

$params = [];
$types  = "";

// Search filter
if ($search !== "") {
    $sql .= " AND (u.user_name LIKE ? OR a.company_name LIKE ?)";
    $like = "%".$search."%";
    $params[] = $like;
    $params[] = $like;
    $types .= "ss";
}

// Status filter
if ($status !== "" && in_array($status, ['pending','approved','rejected'])) {
    $sql .= " AND a.application_status = ?";
    $params[] = $status;
    $types .= "s";
}

$sql .= " ORDER BY a.created_at DESC";

// Prepare & Execute
$stmt = $conn->prepare($sql);

// Bind params only if exist
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
// ❗PENTING: close sekali je, lepas get_result() dah okay
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>All Applications</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/bg-only.css">
</head>

<body class="bg-dashboard bg-admin">

<?php include "../config/navbar.php"; ?>

<div class="container-fluid mt-4">
  <div class="row">

    <!-- Sidebar -->
    <?php include "../config/sidebar.php"; ?>

    <!-- Main -->
    <div class="col-md-9">

      <div class="card shadow mb-4">
        <div class="card-header text-white" style="background:#198754;">
          <h5 class="mb-0">All Applications</h5>
        </div>

        <div class="card-body">
          <form method="GET" class="row g-2 mb-3">
            <div class="col-md-6">
              <input type="text" name="search" class="form-control" placeholder="Search student/company"
                     value="<?= htmlspecialchars($search) ?>">
            </div>

            <div class="col-md-4">
              <select name="status" class="form-select">
                <option value="">All Status</option>
                <option value="pending"  <?= $status==='pending'?'selected':'' ?>>Pending</option>
                <option value="approved" <?= $status==='approved'?'selected':'' ?>>Approved</option>
                <option value="rejected" <?= $status==='rejected'?'selected':'' ?>>Rejected</option>
              </select>
            </div>

            <div class="col-md-2 d-grid">
              <button class="btn btn-success">Filter</button>
            </div>
          </form>

          <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
              <thead class="table-light">
                <tr>
                  <th>Student</th>
                  <th>Resume</th>
                  <th>Company</th>
                  <th>Position</th>
                  <th>Status</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody>
                <?php if($result && $result->num_rows > 0): ?>
                  <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                      <td><?= htmlspecialchars($row['user_name']) ?></td>
                      <td><?= htmlspecialchars($row['resume_title']) ?></td>
                      <td><?= htmlspecialchars($row['company_name']) ?></td>
                      <td><?= htmlspecialchars($row['internshio_position']) ?></td>
                      <td><?= ucfirst($row['application_status']) ?></td>
                      <td><?= htmlspecialchars($row['created_at']) ?></td>
                    </tr>
                  <?php endwhile; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="6" class="text-center text-muted">No applications found.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

        </div>
      </div>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
