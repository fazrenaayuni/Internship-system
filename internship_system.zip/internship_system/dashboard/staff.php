<?php
session_start();
include "../config/db.php";

// Only staff
if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff'){
    header("Location: ../auth/login.php");
    exit();
}

// Fetch staff info
$stmt = $conn->prepare("SELECT user_name, user_role FROM users WHERE user_id=?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result_user = $stmt->get_result();
$user = $result_user->fetch_assoc();
$staff_name = $user['user_name'] ?? 'Staff';
$staff_role = ucfirst($user['user_role'] ?? 'Staff');

// Search applications
$search = $_GET['search'] ?? '';
$search_safe = mysqli_real_escape_string($conn, $search);
$search_sql = $search ? " AND (u.user_name LIKE '%$search_safe%' OR a.company_name LIKE '%$search_safe%')" : "";

// Pending apps
$pending_apps_query = "SELECT a.application_id, u.user_name, r.resume_title, a.company_name, a.internshio_position, a.application_status
                       FROM applications a
                       JOIN resumes r ON a.resume_id = r.resume_id
                       JOIN users u ON a.user_id = u.user_id
                       WHERE a.application_status='pending' $search_sql
                       ORDER BY a.created_at DESC";
$pending_apps = mysqli_query($conn, $pending_apps_query);

// All apps
$all_apps_query = "SELECT a.application_id, u.user_name, r.resume_title, a.company_name, a.internshio_position, a.application_status
                   FROM applications a
                   JOIN resumes r ON a.resume_id = r.resume_id
                   JOIN users u ON a.user_id = u.user_id
                   WHERE 1 $search_sql
                   ORDER BY a.created_at DESC";
$all_apps = mysqli_query($conn, $all_apps_query);

// Stats
$total_pending  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='pending'"))['total'];
$total_approved = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='approved'"))['total'];
$total_rejected = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM applications WHERE application_status='rejected'"))['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Staff Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/bg-only.css">
</head>

<body class="bg-dashboard">

<?php include "../config/navbar.php"; ?>

<div class="container-fluid mt-4">
  <div class="row">

    <?php include "../config/sidebar.php"; ?>

    <div class="col-md-9">

      <!-- Stats -->
      <div class="row mb-4">
        <div class="col-md-4 mb-3">
          <div class="card text-white bg-warning shadow">
            <div class="card-body">
              <h5 class="card-title">Pending Applications</h5>
              <p class="card-text fs-3 fw-bold"><?= $total_pending ?></p>
            </div>
          </div>
        </div>

        <div class="col-md-4 mb-3">
          <div class="card text-white bg-success shadow">
            <div class="card-body">
              <h5 class="card-title">Approved Applications</h5>
              <p class="card-text fs-3 fw-bold"><?= $total_approved ?></p>
            </div>
          </div>
        </div>

        <div class="col-md-4 mb-3">
          <div class="card text-white bg-danger shadow">
            <div class="card-body">
              <h5 class="card-title">Rejected Applications</h5>
              <p class="card-text fs-3 fw-bold"><?= $total_rejected ?></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Pending Table -->
      <div class="card shadow mb-4">
        <div class="card-header bg-warning text-white">Pending Applications</div>
        <div class="card-body">
          <form method="GET" class="d-flex gap-2 mb-3">
            <input type="text" name="search" class="form-control" placeholder="Search student/company"
                   value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-secondary">Search</button>
          </form>

          <table class="table table-bordered table-striped">
            <thead class="table-light">
              <tr>
                <th>Student</th><th>Resume</th><th>Company</th><th>Position</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if(mysqli_num_rows($pending_apps) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($pending_apps)): ?>
                  <tr>
                    <td><?= htmlspecialchars($row['user_name']) ?></td>
                    <td><?= htmlspecialchars($row['resume_title']) ?></td>
                    <td><?= htmlspecialchars($row['company_name']) ?></td>
                    <td><?= htmlspecialchars($row['internshio_position']) ?></td>
                    <td><?= ucfirst($row['application_status']) ?></td>
                    <td>
                      <a href="approve.php?id=<?= $row['application_id'] ?>" class="btn btn-sm btn-success"
                         onclick="return confirm('Approve this application?')">Approve</a>
                      <a href="reject.php?id=<?= $row['application_id'] ?>" class="btn btn-sm btn-danger"
                         onclick="return confirm('Reject this application?')">Reject</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="6" class="text-center text-muted">No pending applications found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>

        </div>
      </div>

      <!-- All Table -->
      <div class="card shadow mb-4">
        <div class="card-header bg-secondary text-white">All Applications</div>
        <div class="card-body">
          <table class="table table-bordered table-striped">
            <thead class="table-light">
              <tr>
                <th>Student</th><th>Resume</th><th>Company</th><th>Position</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if(mysqli_num_rows($all_apps) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($all_apps)): ?>
                  <tr>
                    <td><?= htmlspecialchars($row['user_name']) ?></td>
                    <td><?= htmlspecialchars($row['resume_title']) ?></td>
                    <td><?= htmlspecialchars($row['company_name']) ?></td>
                    <td><?= htmlspecialchars($row['internshio_position']) ?></td>
                    <td><?= ucfirst($row['application_status']) ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted">No applications found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>




