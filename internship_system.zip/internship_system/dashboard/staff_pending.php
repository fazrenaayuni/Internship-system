<?php
include "../config/functions.php";
check_login('staff');

$search = trim($_GET['search'] ?? '');
$search_safe = mysqli_real_escape_string($conn, $search);
$where = $search ? " AND (u.user_name LIKE '%$search_safe%' OR a.company_name LIKE '%$search_safe%')" : "";

$sql = "
SELECT a.application_id, u.user_name, r.resume_title,
       a.company_name, a.internshio_position, a.application_status
FROM applications a
JOIN users u ON a.user_id = u.user_id
JOIN resumes r ON a.resume_id = r.resume_id
WHERE a.application_status='pending' $where
ORDER BY a.created_at DESC
";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Pending Applications</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background:#f4f6f9;">
<?php include "../config/navbar.php"; ?>

<div class="container-fluid mt-4">
  <div class="row">
    <?php include "../config/sidebar.php"; ?>

    <div class="col-md-9">
      <div class="card shadow">
        <div class="card-header bg-warning text-white">Pending Applications</div>
        <div class="card-body">

          <form class="d-flex mb-3" method="GET">
            <input class="form-control me-2" name="search" placeholder="Search student/company"
                   value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-secondary">Search</button>
            <?php if($search): ?>
              <a href="staff_pending.php" class="btn btn-outline-secondary ms-2">Reset</a>
            <?php endif; ?>
          </form>

          <table class="table table-bordered table-striped">
            <thead class="table-light">
              <tr>
                <th>Student</th>
                <th>Resume</th>
                <th>Company</th>
                <th>Position</th>
                <th>Status</th>
                <th width="25%">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if(mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                  <tr>
                    <td><?= htmlspecialchars($row['user_name']) ?></td>
                    <td><?= htmlspecialchars($row['resume_title']) ?></td>
                    <td><?= htmlspecialchars($row['company_name']) ?></td>
                    <td><?= htmlspecialchars($row['internshio_position']) ?></td>
                    <td><?= ucfirst($row['application_status']) ?></td>
                    <td>
                      <a href="approve.php?id=<?= $row['application_id'] ?>" class="btn btn-sm btn-success"
                         onclick="return confirm('Approve this application?')">Approve</a>
                      <a href="reject.php?id=<?= $row['application_id'] ?>" class="btn btn-sm btn-danger"
                         onclick="return confirm('Reject this application?')">Reject</a>
                      <a href="remark.php?id=<?= $row['application_id'] ?>" class="btn btn-sm btn-dark">Remark</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="6" class="text-center text-muted">No pending applications.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>

        </div>
      </div>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
