<?php
session_start();
include "../config/db.php";
include "../config/navbar.php";
include "../config/sidebar.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin'){
    header("Location: ../auth/login.php");
    exit();
}
?>

<div class="col-md-9">
    <h3>All Applications</h3>
    <p>Ini adalah page untuk admin tengok semua applications. Kau boleh paste table applications dari `admin.php` sini.</p>
</div>
