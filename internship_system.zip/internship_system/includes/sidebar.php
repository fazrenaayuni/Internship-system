<div class="d-flex flex-column vh-100 bg-light p-3">
    <a href="#" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
        <span class="fs-4">Dashboard</span>
    </a>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
            <a href="admin.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'admin.php' ? 'active' : '' ?>">
                <i class="bi bi-house"></i> Home
            </a>
        </li>
        <li>
            <a href="profile.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : '' ?>">
                <i class="bi bi-person"></i> Profile
            </a>
        </li>
        <li>
            <a href="internship_position.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'internship_position.php' ? 'active' : '' ?>">
                <i class="bi bi-briefcase"></i> Internship Positions
            </a>
        </li>
        <li>
            <a href="applications.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'applications.php' ? 'active' : '' ?>">
                <i class="bi bi-card-checklist"></i> Applications
            </a>
        </li>
        <li>
            <a href="auth/logout.php" class="nav-link text-danger">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </li>
    </ul>
</div>

