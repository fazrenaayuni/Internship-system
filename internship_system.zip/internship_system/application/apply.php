<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'student') {
    header("Location: ../auth/login.php");
    exit();
}

if (isset($_POST['apply'])) {
    $user_id   = $_SESSION['user_id'];
    $resume_id = $_POST['resume_id'];
    $company   = $_POST['company_name'];
    $position  = $_POST['position'];

    $stmt = mysqli_prepare($conn, "INSERT INTO applications (user_id, resume_id, company_name, internship_position, application_status, created_at, updated_at) VALUES (?, ?, ?, ?, 'pending', NOW(), NOW())");
    mysqli_stmt_bind_param($stmt, "iiss", $user_id, $resume_id, $company, $position);

    if (mysqli_stmt_execute($stmt)) {
        echo "Application submitted successfully!";
    } else {
        echo "Error: " . mysqli_stmt_error($stmt);
    }
    mysqli_stmt_close($stmt);
}
?>

<h3>Apply Internship</h3>
<form method="POST">
    <label>Select Resume:</label>
    <select name="resume_id" required>
        <?php
        $user_id = $_SESSION['user_id'];
        $resumes = mysqli_query($conn, "SELECT * FROM resume WHERE user_id=$user_id");
        while($r = mysqli_fetch_assoc($resumes)) {
            echo "<option value='{$r['resume_id']}'>{$r['resume_title']}</option>";
        }
        ?>
    </select><br>
    <input name="company_name" placeholder="Company Name" required><br>
    <input name="position" placeholder="Position" required><br>
    <button name="apply">Apply</button>
</form>
